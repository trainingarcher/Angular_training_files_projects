import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-clock',
  templateUrl: './clock.component.html',
  styleUrls: ['./clock.component.css']
})
export class ClockComponent implements OnInit {

  dateString: string="";
  timeString: string="";
  constructor() { 
    setInterval(()=>{
      this.dateString ="Date is: "+ new Date().toDateString();
      this.timeString="Date is: "+ new Date().toTimeString();
    },1000);

  }

  ngOnInit(): void {
  }

}
