import { Component } from '@angular/core';
import { StudentModule } from './student/student.module';

@Component({
  selector: 'app-base',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'module-component-demo';
}
