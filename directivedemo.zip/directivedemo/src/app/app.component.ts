import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'directivedemo';

  condition=true
  flag=true

  cond1 = true;
  cond2 = true;
  cond3 = false;


  student_list = [{
    'ID' : '11', 
    'Name' : 'Amit', 
    'Email':'abc@gmail.com'
  },

  {
   'ID' : '22', 
   'Name' : 'Sunil', 
   'Email':'xyz@gmail.com'
  },

  {
    'ID' : '33', 
    'Name' : 'Radha', 
    'Email':'pqr@gmail.com'
  },
  {
    'ID' : '44', 
    'Name' : 'Ajit', 
    'Email':'ajit@gmail.com'
  },

  {
   'ID' : '55', 
   'Name' : 'Sunita', 
   'Email':'sunita@gmail.com'
  },

  {
    'ID' : '66', 
    'Name' : 'Ravi', 
    'Email':'ravi@gmail.com'
  }]

  num : number=2

  dyst='ds';
}
