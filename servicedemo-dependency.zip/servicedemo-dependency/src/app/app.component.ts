import { Component } from '@angular/core';
import { Product } from './product';
import { ProductService } from './product.service';
import { LoggerService } from './logger.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'servicedemo-dependency';
    
    products:Product[] = [];
    
    constructor(private productService:ProductService) {    
      
    } 
    
    getProducts() {
      
      this.products=this.productService.getProducts();
    }
}
