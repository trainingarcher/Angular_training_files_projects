import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pipedemo';
  str : string = "This Is the DEMO String";

  currdate: Date = new Date();

  num: number= 9542.14554;

  per: number= 0.7414;

  cur: number= 175.4575775;
}
