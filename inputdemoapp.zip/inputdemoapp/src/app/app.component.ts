import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'inputdemoapp';
  data: string="";
  fndlst :string[]=[];
  colors :string[]=[];
  tasks :string[]=[];
  deleteditem : string = "";
  count : number = 0;

  passValue(evt:any){
    const val = evt.target.value;
    //console.log(val);
    this.data=val;
  }

  addToFriendList(evt:any){
    const val = evt.target.value;
    this.fndlst.push(val);
  }

  afterColorAdd(evt:any){
    //console.log(evt);
    this.colors.push(evt);
  }

  addTask(task:any){
    this.tasks.push(task);
   // console.log(task);
  }

  removeTask(taskindex:number){
    this.deleteditem = this.tasks[taskindex];
    this.tasks = this.tasks.filter( (val,index)=>index !== taskindex)
  }

  addToQty(val:any){
    this.count = +val;
  }

  showData(val:number){
    this.count=val;
  }
}
