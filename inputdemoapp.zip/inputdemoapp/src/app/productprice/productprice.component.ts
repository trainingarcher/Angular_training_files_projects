import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-productprice',
  templateUrl: './productprice.component.html',
  styleUrls: ['./productprice.component.css']
})
export class ProductpriceComponent implements OnInit {

  @Input() item : number=0;
  @Output() itemChange = new EventEmitter<number>();
  itemprice : number = 15 ;
  constructor() { }

  ngOnInit(): void {
  }

  incrQty(){
    this.item +=1
    this.updateQty();
  }
  decrQty(){
    this.item -=1
    this.updateQty();
  }

  updateQty(){
    this.itemChange.emit(this.item);
  }

}
